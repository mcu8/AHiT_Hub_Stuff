/*

                    o + o    / ----------------------------- \    o + o
                          O || Template map for HUB Swapper  || O 
                    o + o    \ ----------------------------- /    o + o
    
    =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+

     This allows you to create a map without the need to script anything!!!
     YES, that mod has implemented "addon loader", unfortunelly, only one hub map can 
     be loaded at once... (that's some engine limitation, I cannot do much about it...)

    =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
     I.   BEFORE YOU START **PLEASE READ**
    =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
     0. First, remove the steam version of the HUB Swapper
     1. Download https://github.com/mcu8/AHiT_Hub_Stuff/tree/main/Releases/mcu8_mods_BH.zip
        and extract the "mcu8_mods_BH" folder from the archive into your "Mods" folder
     2. Launch Mod Manager, click on the "HUB Swapper" mod icon, then [</>] and 
        click "Compile scripts" button, wait for it to finish...

     - That's it, you're ready to go! :> - 

    =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
     II.  MAKING THE MAP
    =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
     1. Create new mod in Modding Tools and launch the editor
     2. Load my template map "hubexmap_ExampleHubMap.umap" in the editor
     3. !!! DONT MODIFY IT !!! - save it as "hubexmap_<insert_some_random_name_here>.umap" 
        (prefix is important!!! don't miss it!!!) to the "Maps" folder where your 
        new mod is stored
     4. Load that previously saved map - enjoy modding!

    =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
     [!] Don't forget to add HUB Swapper as the dependency to your mod on the Steam Workshop!
    =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+

                                         By m_cu8 @ https://hat.ovh | https://twitter.com/mcu82

 */
